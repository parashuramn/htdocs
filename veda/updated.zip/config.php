<?php
$dbname = "scorm";
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
?>  
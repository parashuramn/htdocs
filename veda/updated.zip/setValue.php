<?php

//  database login information
require "config.php";

// connect to the database
$link = mysql_connect($dbhost,$dbuser,$dbpass);
mysql_select_db($dbname,$link);

// read GET and POST variables
$varname = $_REQUEST['varname'];
$varvalue = $_REQUEST['varvalue'];
// make safe for database
$safevarname = mysql_escape_string($varname);
$safevarvalue = mysql_escape_string($varvalue);
// save data to the 'scormvars' table
mysql_query("delete from scormvars where (varName='$safevarname')",$link);
mysql_query("insert into scormvars (varName,varValue) values ('$safevarname','$safevarvalue')",$link);
// return value to the calling program
print "true";
?>

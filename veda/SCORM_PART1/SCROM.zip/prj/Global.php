 <?php 

 static $scormvars = array(array(),array());
 print_r('Variables'.$scormvars);
 static $count=0
 ?>
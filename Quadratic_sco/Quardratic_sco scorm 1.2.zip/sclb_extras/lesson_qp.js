/**
 *  ==================================================
 *  SoftChalk LessonBuilder q_parameters.js
 *  Copyright 2003-2010 SoftChalk LLC
 *  All Rights Reserved.
 *
 *  http://www.softchalk.com
 *  ==================================================
 */

q_item=1;
group_item=0;
tableToggle_array=new Array();
f_done=new Array();
feed=new Array();
q_done=new Array();
scoreQ=new Array();
qOrder=new Array();
qOrder[0]=1;
num_pages=5;
scorm_completed_status=true;

//q_num=1;
inline_feedback1=true;
q_done[1]=false;
q_value1=5;
scoreQ[1]="yes";
mc_items1=3;
//ra_items1=3;
q_type1=5;
theQuestion1="Match the items.";
showCorrect1="no";
showHint1="no";
case_sensitive1="false";
partial_credit1=false;
feedbackRight1="Right! Good job!";
feedbackWrong1="Sorry, incorrect answer. remember the Discriminant is found by the following formula:</p><p><span id=\"inlinemedia26\"><img src=\"ada-equation.gif\" title=\"equation image indicator\" longdesc=\"ada_files/ada_equation26.html\" border=\"0\"><img src=\"lessonimages/equation_image26.gif\" border=\"0\" style=\"vertical-align: middle\"></span>";
feedbackPartial1="Partially correct.";
hint1="";
right_answers1=new Array(3);
right_answers1[0]="1";
right_answers1[1]="2";
right_answers1[2]="0";
answer_choices1=new Array(3);
answer_choices1[0]="<img vspace=\"10\" src=\"Above.png\" hspace=\"30\" height=\"80\" alt=\"Above.png\" width=\"204\" border=\"0\">";
answer_choices1[1]="<img vspace=\"10\" src=\"Below.png\" hspace=\"30\" height=\"69\" alt=\"Below.png\" width=\"204\" border=\"0\">";
answer_choices1[2]="<img vspace=\"10\" src=\"ON.png\" hspace=\"30\" height=\"80\" alt=\"ON.png\" width=\"204\" border=\"0\">";
tableToggle_array[1]=true;
f_done[1]=false;
feed[1]=false;
//colorChoice1="_custom";
//tableClass1="expand";
//openerImage1="selfcheck_custom.gif";
//items_to_match1[0]="<img vspace="10" src="Example1.gif" hspace="30" height="21" alt="Example1.gif" width="73" border="0">";
//items_to_match1[1]="<img vspace="10" src="Example2.gif" hspace="30" height="21" alt="Example2.gif" width="76" border="0">";
//items_to_match1[2]="<img vspace="10" src="Example5.gif" hspace="30" height="21" alt="Example5.gif" width="91" border="0">";
//allowRetry1=true;
//groupID1=0;


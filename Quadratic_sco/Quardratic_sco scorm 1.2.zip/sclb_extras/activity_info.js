/**
 *  ==================================================
 *  SoftChalk LessonBuilder
 *  Activity activity_info.js
 *  Copyright 2008 SoftChalk LLC
 *  All Rights Reserved.
 *
 *  http://www.softchalk.com
 *  ==================================================
 */

q_done_a=new Array();
scoreQa=new Array();
score_a=new Array();
show_restart_a=new Array();
num_pages=5;
actOrder=new Array(1);
actOrder[0]=1;

//a_num=1;
a_value1=5;
scoreQa[1]=true;
q_done_a[1]=false;
score_a[1]=0;
show_restart_a[1]=true;

